package com.stadium.entity;

import lombok.Data;

@Data
public class Time {
    int id;
    String time;
}
