package com.stadium.entity;

import lombok.Data;

@Data
public class StVenue {
    int id;
    String time;
    String location;
}
